﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opc2Lib
{
    public class Command
    {
        public CommandInfo Info { get; set; }
        public object Value { get; set; }
    }
}
